# Midas Tools — AI Prompt Mega Pack
# 05: Personal Branding & Career Prompts

Build your personal brand, land better opportunities, and position yourself as an authority. These prompts help you stand out in any industry.

---

## Variables Reference

```
[YOUR NAME] — Your full name
[YOUR TITLE] — Current role or desired title
[YOUR NICHE] — Your area of expertise
[YOUR EXPERIENCE] — Years of experience, key achievements
[TARGET ROLE] — Job or position you want
[TARGET COMPANY] — Dream company or type
[YOUR SKILLS] — Top 5 skills
[YOUR STORY] — Brief career/life narrative
[YOUR GOAL] — What you're building toward
```

---

## Prompt 1: Personal Brand Strategy

### Prompt

```
Create a comprehensive personal brand strategy for me.

About me:
- Name: [YOUR NAME]
- Current role: [YOUR TITLE]
- Industry: [YOUR NICHE]
- Experience: [YOUR EXPERIENCE]
- Skills: [YOUR SKILLS]
- Unique angle: [WHAT MAKES YOU DIFFERENT]
- Goal: [YOUR GOAL]

Develop:

**1. Brand positioning statement:**
"I help [WHO] achieve [WHAT] through [HOW]"

**2. Content pillars (3-5 themes):**
For each pillar:
- Topic area
- Why you're credible here
- Content ideas (5 per pillar)
- Target keyword/hashtag

**3. Platform strategy:**
- Primary platform: [RECOMMENDATION + WHY]
- Secondary platform: [RECOMMENDATION + WHY]
- Posting frequency for each
- Content format mix

**4. Authority building plan:**
- Month 1-3: Foundation (what to do)
- Month 3-6: Growth (what to do)
- Month 6-12: Authority (what to do)
- Milestone markers for each phase

**5. Brand voice guide:**
- 3 words that describe your tone
- How you open posts
- How you close posts
- Words/phrases you use often
- Words/phrases you never use

**6. Visual brand suggestions:**
- Color palette
- Photo style
- Graphics approach
- Profile consistency across platforms
```

### How to Use
Commit to one platform for 90 days before adding another. Consistency beats perfection.

---

## Prompt 2: LinkedIn Profile Optimization

### Prompt

```
Rewrite my LinkedIn profile for maximum impact and searchability.

Current info:
- Name: [YOUR NAME]
- Current role: [YOUR TITLE] at [COMPANY]
- Industry: [YOUR NICHE]
- Experience: [BRIEF CAREER HISTORY]
- Top achievements: [3-5 KEY WINS WITH NUMBERS]
- Skills: [YOUR SKILLS]
- Goal: [WHAT YOU WANT — jobs, clients, partnerships, authority]
- Target audience on LinkedIn: [WHO YOU WANT TO ATTRACT]

Rewrite:

**Headline (120 chars):**
3 options — not just your title, but your value proposition
Example: "Helping [WHO] do [WHAT] | [CREDENTIAL] | [RESULT]"

**About section (2,600 chars max):**
- Hook (first 2 lines visible before "see more")
- Your story — not a resume, a narrative
- Who you help and how
- Key results with numbers
- What people can expect from your content
- CTA (what to do next — DM, follow, visit link)

**Experience (current role):**
- Rewrite as achievements, not responsibilities
- Start each bullet with a result
- Include metrics where possible

**Featured section suggestions:**
- What to pin (posts, articles, links)
- Why each item builds credibility

**Skills to list** (top 10, ordered by relevance)

**Keywords to include** for search visibility:
[LIST 10-15 KEYWORDS based on their goal]

**Headline formula comparison:**
Show 3 options rated by: Clarity / Authority / Curiosity
```

### How to Use
Update quarterly. Your LinkedIn profile is a landing page — optimize it like one. Ask 5 connections to endorse your top skills.

---

## Prompt 3: Resume/CV Writer

### Prompt

```
Write a professional resume for a [TARGET ROLE] position.

My details:
- Name: [YOUR NAME]
- Target role: [TARGET ROLE]
- Target company type: [TARGET COMPANY]
- Current role: [CURRENT TITLE AT CURRENT COMPANY]
- Years of experience: [NUMBER]
- Education: [DEGREES/CERTIFICATIONS]
- Key skills: [YOUR SKILLS]

Work history (provide for each role):
- Company: [COMPANY NAME]
- Title: [YOUR TITLE]
- Duration: [START-END]
- Key responsibilities: [BRIEF LIST]
- Achievements: [SPECIFIC RESULTS WITH NUMBERS]

Write:

**1. Professional summary (3-4 lines):**
- Lead with years of experience + area of expertise
- Include your biggest quantified achievement
- End with what you bring to the target role

**2. Work experience (for each role):**
- Rewrite as achievement bullets, not job descriptions
- Start each bullet with a strong action verb
- Include metrics: revenue, percentage improvements, team size, etc.
- 3-5 bullets per recent role, 2-3 for older roles
- Tailor to [TARGET ROLE] requirements

**3. Skills section:**
- Technical skills
- Soft skills (reframed as competencies)
- Tools/software

**4. ATS optimization:**
- Keywords from typical [TARGET ROLE] job descriptions
- Formatting rules for ATS compatibility
- File format recommendation

Also provide:
- Cover letter (300 words) tailored to [TARGET COMPANY]
- Follow-up email template (after interview)
- 5 questions to ask in the interview
```

### How to Use
Customize for each application. Generic resumes get generic results. Mirror the language from the job posting.

---

## Prompt 4: Thought Leadership Article

### Prompt

```
Write a thought leadership article that positions me as an authority in [YOUR NICHE].

About me:
- Name: [YOUR NAME]
- Expertise: [YOUR NICHE]
- Experience: [YOUR EXPERIENCE]
- Unique perspective: [WHAT DO YOU BELIEVE THAT MOST PEOPLE IN YOUR INDUSTRY DON'T?]
- Target audience: [WHO SHOULD READ THIS]

Article requirements:
- Length: 1,200-1,800 words
- Publish platform: [LINKEDIN / MEDIUM / PERSONAL BLOG / INDUSTRY PUBLICATION]
- Tone: Authoritative but accessible

Structure:
1. **Bold opening** — Challenge a conventional wisdom or state an unexpected trend
2. **Context** — Why this matters now (data, market shift, personal observation)
3. **Your framework** — Present a unique way of thinking about [TOPIC]
4. **Evidence** — 2-3 examples that support your point (case studies, data, experience)
5. **Practical application** — How the reader can apply this insight
6. **Future implications** — What this means for the industry in 2-3 years
7. **Strong close** — Memorable final line that people will quote

Requirements:
- Original perspective (not restating what everyone already knows)
- Specific examples and data points
- Actionable insights
- Written in first person with confidence
- Include subheadings for readability

Also provide:
- 5 title options (optimized for [PLATFORM])
- Social media teaser post
- Key quote for pull graphic
```

### How to Use
Publish one thought leadership piece per month. Share it across all platforms. Tag people you reference for amplification.

---

## Prompt 5: Elevator Pitch Generator

### Prompt

```
Create elevator pitches for different contexts.

About me/my business:
- Name: [YOUR NAME]
- What I do: [YOUR BUSINESS/ROLE]
- Who I help: [TARGET AUDIENCE]
- Key result: [BIGGEST OUTCOME YOU DELIVER]
- Differentiator: [WHAT MAKES YOU UNIQUE]

Write pitches for:

**1. The 10-second pitch:**
"I help [WHO] [ACHIEVE WHAT] by [HOW]."
- 3 versions: professional, casual, intriguing

**2. The 30-second pitch (networking events):**
- Hook: One sentence that creates curiosity
- Context: What you do
- Proof: One specific result
- CTA: How to continue the conversation

**3. The 60-second pitch (investor/partner):**
- Problem: What pain exists
- Solution: What you've built
- Traction: What results you have
- Ask: What you need

**4. The "What do you do?" response (social settings):**
- 3 versions: humble, confident, intriguing
- Each should invite a follow-up question

**5. The email introduction (when someone introduces you):**
- One paragraph someone can forward about you
- Include your best credential and what you're looking for

For each:
- Conversational (not scripted-sounding)
- Memorable (one thing they'll remember)
- Actionable (clear next step)
```

### How to Use
Practice each version until it feels natural. The best pitch doesn't sound like a pitch — it sounds like an interesting conversation.

---

## Prompt 6: Speaking & Presentation Prep

### Prompt

```
Help me prepare for a speaking engagement about [TOPIC].

Details:
- Event: [EVENT NAME/TYPE]
- Audience: [WHO WILL BE THERE]
- Duration: [LENGTH]
- Format: [KEYNOTE / PANEL / WORKSHOP / WEBINAR]
- My expertise in this topic: [YOUR EXPERIENCE]
- Key message I want the audience to walk away with: [ONE SENTENCE]

Create:

**1. Presentation outline:**
- Opening (grab attention in 30 seconds)
- 3-5 main points with supporting stories/data
- Transitions between sections
- Audience interaction moments
- Closing (memorable, actionable)

**2. Speaker notes:**
- Key talking points per slide
- Stories to tell (with setup and punchline)
- Data points to reference
- Callbacks to earlier points

**3. Slide suggestions:**
- Title and key visual for each slide
- Rule: No slide should have more than 6 words
- Image/graphic descriptions

**4. Audience engagement:**
- Opening question/poll
- Mid-talk interaction
- Q&A preparation (10 likely questions with answers)

**5. Speaker bio (for event materials):**
- Short version (50 words)
- Long version (150 words)

**6. Post-talk follow-up:**
- Slide deck sharing strategy
- Social media posts about the talk
- Email to attendees who give you their card
```

### How to Use
Practice 3x minimum. Record yourself. The first 30 seconds determine whether the audience stays with you.

---

## Prompt 7: Portfolio & Case Study Writer

### Prompt

```
Write a compelling case study for my portfolio.

Project/client details:
- Client/Project: [NAME — anonymize if needed]
- Industry: [THEIR INDUSTRY]
- Challenge: [WHAT PROBLEM THEY HAD]
- Your role: [WHAT YOU DID]
- Solution: [WHAT YOU BUILT/IMPLEMENTED]
- Results: [SPECIFIC OUTCOMES WITH NUMBERS]
- Timeline: [HOW LONG IT TOOK]
- Tools/skills used: [TECHNOLOGIES/METHODS]

Case study structure:

**1. Headline:** Result-focused, specific
"How [Client] achieved [Result] in [Timeframe]"

**2. The Challenge (100-150 words):**
- Situation before you got involved
- Specific pain points
- What was at stake

**3. The Approach (150-200 words):**
- Your diagnosis
- Why you chose this approach
- Key decisions and trade-offs

**4. The Execution (200-300 words):**
- Step-by-step what you did
- Obstacles and how you overcame them
- Collaboration with the client

**5. The Results (100-150 words):**
- Primary metric improvement (with number)
- Secondary wins
- Client quote (if available)
- Before/after comparison

**6. Key Takeaway (50 words):**
- One insight that makes you look like an expert

Also provide:
- One-paragraph version (for website overview)
- Thumbnail description (for portfolio grid)
- Social media post sharing this case study
```

### How to Use
Aim for 3-5 strong case studies. Quality beats quantity. Each should showcase a different skill or type of result.

---

## Prompt 8: Networking Follow-Up Messages

### Prompt

```
Write networking follow-up messages for various scenarios.

My details:
- Name: [YOUR NAME]
- What I do: [YOUR ROLE/BUSINESS]
- Goal: [WHAT YOU'RE BUILDING TOWARD]

Write follow-up messages for:

**1. After meeting at a conference/event:**
- Within 24 hours
- Reference something specific from the conversation
- Suggest a specific next step

**2. After a LinkedIn connection request accepted:**
- Thank them for connecting
- Offer value (not a pitch)
- Open the conversation naturally

**3. After an informational interview:**
- Express genuine gratitude
- Reference a specific insight they shared
- Offer to help them with something

**4. Reconnecting after 6+ months:**
- Acknowledge the time gap
- Share something relevant to them
- No pressure, just maintaining the relationship

**5. Introducing two connections:**
- Brief context on why they should meet
- What each brings to the table
- Make it easy to respond

**6. Asking for a referral/introduction:**
- Be specific about who you want to meet
- Explain why (and what's in it for them)
- Make it easy (offer to draft the intro)

**7. Following up after no response:**
- 2nd touch (3-5 days later): gentle nudge
- 3rd touch (2 weeks later): different angle
- Final touch (1 month later): casual close

For each:
- Under 100 words
- Warm and personal (not templated)
- Clear CTA
- Easy to respond to (yes/no question)
```

### How to Use
Follow up within 24 hours of meeting someone. The fortune is in the follow-up. Set calendar reminders.

---

## Prompt 9: Annual Review & Goal Setting

### Prompt

```
Help me conduct an annual review and set goals for the coming year.

My details:
- Role: [YOUR TITLE]
- Industry: [YOUR NICHE]
- Years in career: [NUMBER]
- Current salary/revenue: [AMOUNT]
- Last year's goals: [LIST THEM]

**Annual Review:**

1. **Wins inventory:**
   - What did I accomplish? (prompt me to list 10+)
   - What skills did I develop?
   - What relationships did I build?
   - What did I create or ship?

2. **Lessons learned:**
   - What failed and why?
   - What would I do differently?
   - What assumptions were wrong?

3. **Energy audit:**
   - What work energized me?
   - What drained me?
   - What should I do more of? Less of?

4. **Metrics review:**
   - Revenue/salary growth
   - Network growth
   - Skills acquired
   - Content published
   - Opportunities created

**Goal Setting (Next Year):**

5. **Vision:** Where do I want to be in 12 months?

6. **3-5 annual goals** using the framework:
   - Goal statement (specific, measurable)
   - Why it matters
   - Lead indicators (weekly actions that drive it)
   - Lag indicators (how I'll measure success)
   - Potential obstacles
   - Quarterly milestones

7. **90-day sprint:**
   - The ONE goal to focus on in Q1
   - Weekly actions required
   - Accountability mechanism

8. **Anti-goals:**
   - What I'm deliberately NOT pursuing this year
   - Why (prevents distraction)

Present as a structured workbook I can fill out.
```

### How to Use
Do this between Christmas and New Year. Review quarterly. Adjust goals as you learn — rigid goals with flexible methods.

---

## Prompt 10: Salary / Rate Negotiation Prep

### Prompt

```
Help me prepare for a salary/rate negotiation.

Context:
- My role: [YOUR TITLE]
- Company/Client: [WHO YOU'RE NEGOTIATING WITH]
- Current compensation: [CURRENT PAY]
- Desired compensation: [TARGET PAY]
- Market rate for this role: [IF KNOWN]
- My tenure: [HOW LONG IN THE ROLE]
- Recent achievements: [TOP 3 WINS WITH METRICS]
- Leverage: [JOB OFFERS, HARD-TO-REPLACE SKILLS, KEY PROJECT OWNERSHIP]
- Relationship: [YOUR RELATIONSHIP WITH THE DECISION-MAKER]

Provide:

**1. Market research framework:**
- Where to find salary data for [YOUR TITLE]
- How to calculate your market value
- Factors that increase your value

**2. Negotiation script:**
- Opening statement (confident, not aggressive)
- How to present your case (Achievement → Impact → Ask)
- How to state your number (and why you chose it)
- Silence techniques (after stating your number)
- How to respond to: "That's above our budget"
- How to respond to: "We can review in 6 months"
- How to respond to: counter-offer below your target

**3. Non-salary levers:**
- What else to negotiate if salary is capped
- Remote work, equity, bonuses, title, vacation, education budget
- How to value each in dollar terms

**4. Walk-away preparation:**
- Your minimum acceptable offer
- Script for declining gracefully
- How to keep the door open

**5. Follow-up:**
- Get it in writing (email template)
- Thank-you message regardless of outcome
```

### How to Use
Never negotiate without preparation. Know your number, know your walk-away, and practice the conversation out loud.

---

## Pro Tips: Personal Branding

1. **Be known for ONE thing** — Multi-passionate is fine, but market one expertise
2. **Show your work** — Share the process, not just the results
3. **Consistency > Virality** — Post regularly, even if nobody's watching at first
4. **Give before you ask** — Help 10 people before asking for anything
5. **Your network IS your net worth** — Invest in relationships, not just followers
6. **Own your platform** — Build an email list. Social followers can disappear overnight.
7. **Be authentically professional** — You don't need to be "relatable" — you need to be trustworthy
