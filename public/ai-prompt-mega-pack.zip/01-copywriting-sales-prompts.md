# Midas Tools — AI Prompt Mega Pack
# 01: Copywriting & Sales Prompts

Master the art of persuasion with AI. These prompts help you write copy that converts — from headlines to full sales pages, email sequences to ad copy.

---

## Variables Reference

```
[YOUR BUSINESS] — Your company or brand name
[PRODUCT/SERVICE] — What you're selling
[TARGET AUDIENCE] — Who you're writing for
[PRICE] — Your price point
[KEY BENEFIT] — The #1 outcome your customer gets
[PAIN POINT] — The problem your product solves
[TONE] — casual, professional, urgent, witty, authoritative
[COMPETITOR] — Main alternative your audience considers
[TESTIMONIAL] — A real customer quote or result
[CTA] — Your desired call-to-action
```

---

## Prompt 1: Headline Generator (10 Variations)

### Prompt

```
You are a world-class direct response copywriter. Generate 10 headlines for [PRODUCT/SERVICE] targeting [TARGET AUDIENCE].

Product: [PRODUCT/SERVICE]
Key benefit: [KEY BENEFIT]
Pain point: [PAIN POINT]
Price: [PRICE]

Requirements:
- Mix headline formulas: How-to, Question, Number, Command, Testimonial
- Each headline should be under 12 words
- Focus on the transformation, not features
- Include at least 2 headlines with specific numbers
- Include at least 1 headline that creates urgency

Rate each headline 1-10 for:
- Clarity
- Curiosity
- Specificity

Recommend the top 3 for A/B testing and explain why.
```

### How to Use
Run this when launching a new product, writing a landing page, or A/B testing ad copy. Use the top-rated headlines as your starting point.

---

## Prompt 2: Sales Page (Long-Form)

### Prompt

```
Write a high-converting long-form sales page for [PRODUCT/SERVICE].

Context:
- Target audience: [TARGET AUDIENCE]
- Main pain point: [PAIN POINT]
- Key benefit: [KEY BENEFIT]
- Price: [PRICE]
- Competitor alternative: [COMPETITOR]

Structure the page using this proven framework:
1. **Hook** — Open with a bold, specific claim or question
2. **Problem Agitation** — Describe the pain in vivid detail (3 paragraphs)
3. **Failed Solutions** — Why other approaches don't work
4. **The Bridge** — Introduce [PRODUCT/SERVICE] as the solution
5. **How It Works** — 3 simple steps
6. **Social Proof** — Where to place testimonials (use placeholder)
7. **Feature → Benefit Stack** — List 5-7 features, each tied to a benefit
8. **Objection Handling** — Address top 3 objections
9. **Price Anchor** — Compare to alternatives, justify the price
10. **Guarantee** — Risk reversal
11. **CTA** — Clear, urgent call-to-action
12. **PS** — One final compelling reason to buy

Tone: [TONE]
Length: ~1,500 words
Use short paragraphs (1-3 sentences). Bold key phrases. Use "you" language throughout.
```

### How to Use
This is your go-to for product launches, landing pages, and Gumroad listings. Fill in all variables thoroughly for the best output.

---

## Prompt 3: Email Sales Sequence (5 Emails)

### Prompt

```
Write a 5-email sales sequence for [PRODUCT/SERVICE] targeting [TARGET AUDIENCE].

Product details:
- Name: [PRODUCT/SERVICE]
- Price: [PRICE]
- Key benefit: [KEY BENEFIT]
- Pain point: [PAIN POINT]

Email sequence structure:

**Email 1: The Story (Day 0)**
- Subject line options (3)
- Open with a personal story or case study about [PAIN POINT]
- End with curiosity, no hard sell

**Email 2: The Problem (Day 1)**
- Subject line options (3)
- Agitate the pain — what happens if they do nothing
- Introduce [PRODUCT/SERVICE] briefly at the end

**Email 3: The Proof (Day 3)**
- Subject line options (3)
- Share a specific result or testimonial
- Show the before/after transformation

**Email 4: The Objection Killer (Day 5)**
- Subject line options (3)
- Address the top 3 reasons people don't buy
- Include FAQ-style objection handling

**Email 5: The Close (Day 7)**
- Subject line options (3)
- Create urgency (limited time, price going up, bonuses expiring)
- Clear CTA with [PRICE] and guarantee

For each email:
- Write 150-250 words
- Include subject line A/B options
- Use conversational tone
- End with a clear next step
```

### How to Use
Set up this sequence in your email tool. Adjust timing based on your audience (shorter for impulse buys, longer for expensive products).

---

## Prompt 4: Product Description (E-commerce)

### Prompt

```
Write a compelling product description for [PRODUCT/SERVICE].

Details:
- Product: [PRODUCT/SERVICE]
- Target customer: [TARGET AUDIENCE]
- Price: [PRICE]
- Top 3 features: [LIST FEATURES]
- Key differentiator: [WHAT MAKES IT UNIQUE]

Write 3 versions:
1. **Short** (50 words) — for product cards and ads
2. **Medium** (150 words) — for product pages and listings
3. **Long** (300 words) — for detailed product pages with SEO keywords

Each version must:
- Lead with the benefit, not the feature
- Include sensory language
- Have a clear CTA
- Feel premium, not salesy
```

### How to Use
Use the short version for social media and ads, medium for marketplace listings, and long for your own website.

---

## Prompt 5: Facebook/Instagram Ad Copy

### Prompt

```
Write 5 Facebook/Instagram ad variations for [PRODUCT/SERVICE].

Product: [PRODUCT/SERVICE]
Audience: [TARGET AUDIENCE]
Price: [PRICE]
Key benefit: [KEY BENEFIT]
Offer: [ANY SPECIAL OFFER — discount, bonus, free trial]

For each ad, write:
- **Primary text** (125 characters max for mobile)
- **Headline** (40 characters max)
- **Description** (30 characters max)
- **Extended primary text** (for feeds, 300 words max)

Ad angles to cover:
1. Pain point focused — lead with the problem
2. Benefit focused — lead with the transformation
3. Social proof — lead with a result or testimonial
4. Curiosity — create an open loop
5. Urgency — limited time or scarcity

Include emoji suggestions for each ad. Note which ad angle typically performs best for [TARGET AUDIENCE].
```

### How to Use
Test all 5 angles with small budgets ($5-10/day each) for 3-5 days. Scale the winner.

---

## Prompt 6: Google Ads Copy

### Prompt

```
Write Google Search ad copy for [PRODUCT/SERVICE].

Target keywords: [LIST 3-5 KEYWORDS]
Landing page: [URL]
Target audience: [TARGET AUDIENCE]

Create 3 responsive search ad sets. Each set needs:
- 15 headlines (30 characters max each)
- 4 descriptions (90 characters max each)

Requirements:
- Include target keyword in at least 5 headlines
- Include price in at least 2 headlines
- Include CTA in at least 3 headlines
- Mix emotional and rational appeals
- Include at least 2 headlines with numbers/stats
- Descriptions should complement headlines, not repeat them

Also suggest:
- 5 sitelink extensions with descriptions
- 3 callout extensions
- 2 structured snippet extensions
```

### How to Use
Upload all headlines and descriptions — Google will test combinations automatically. Review performance after 2 weeks and pause low-performers.

---

## Prompt 7: Landing Page Above-the-Fold

### Prompt

```
Write the above-the-fold section for a landing page selling [PRODUCT/SERVICE].

Context:
- Traffic source: [WHERE VISITORS COME FROM — ads, social, email, organic]
- Audience: [TARGET AUDIENCE]
- Key benefit: [KEY BENEFIT]
- Price: [PRICE]
- Offer: [ANY SPECIAL OFFER]

Write:
1. **Pre-headline** (badge text, 3-5 words) — social proof or category label
2. **Main headline** (8-12 words) — clear, specific, benefit-driven
3. **Sub-headline** (15-25 words) — expand on the headline, add credibility
4. **3 bullet points** — key features as benefits (start each with a verb)
5. **CTA button text** (4-6 words) — action-oriented, specific
6. **Below-CTA reassurance** (under 10 words) — reduce friction

Provide 3 complete variations with different angles (transformation, pain, social proof).
```

### How to Use
Pick the variation that matches your brand voice. Test different CTAs — button text changes can lift conversions 10-30%.

---

## Prompt 8: Testimonial Request Email

### Prompt

```
Write 3 versions of a testimonial request email for [YOUR BUSINESS].

Context:
- Business: [YOUR BUSINESS]
- Product/service they bought: [PRODUCT/SERVICE]
- How long ago: [TIMEFRAME]
- Known result: [ANY SPECIFIC RESULT YOU KNOW ABOUT]

Each version should:
- Be under 150 words
- Feel personal, not automated
- Make it EASY to respond (include specific questions)
- Offer an incentive if appropriate

Questions to include:
1. What was your situation before [PRODUCT/SERVICE]?
2. What specific result did you get?
3. Would you recommend it? Why?
4. Can we use your response on our website? (First name + industry is fine)

Version 1: Casual & warm
Version 2: Professional & brief
Version 3: Results-focused (for B2B)

Also write a follow-up email for non-responders (send 5 days later).
```

### How to Use
Send 1 week after purchase/delivery. Testimonials are the #1 conversion booster — collect them systematically.

---

## Prompt 9: Pricing Page Copy

### Prompt

```
Write the copy for a pricing page with [NUMBER] tiers for [YOUR BUSINESS].

Tiers:
- Tier 1: [NAME] — [PRICE] — [KEY FEATURES]
- Tier 2: [NAME] — [PRICE] — [KEY FEATURES] (recommended)
- Tier 3: [NAME] — [PRICE] — [KEY FEATURES]

For each tier, write:
- Tier name and tagline (5 words max)
- Price display with anchor (show per-month AND per-year savings)
- 6-8 feature bullets (checkmarks for included, dashes for excluded)
- CTA button text (different for each tier)
- "Best for:" description (one sentence)

Also write:
- Page headline
- Trust badges row (what to show)
- FAQ section (5 questions about pricing)
- Money-back guarantee text

Make the middle tier clearly the best value. Use design suggestions (highlight color, "Most Popular" badge).
```

### How to Use
The middle tier should get 60%+ of signups. If it doesn't, adjust the feature distribution.

---

## Prompt 10: Upsell / Cross-sell Copy

### Prompt

```
Write upsell and cross-sell copy for [YOUR BUSINESS].

Current purchase: [PRODUCT THEY JUST BOUGHT]
Upsell product: [HIGHER-TIER PRODUCT]
Cross-sell product: [COMPLEMENTARY PRODUCT]
Customer: [TARGET AUDIENCE]

Write:

**Post-Purchase Upsell (Thank You Page)**
- Headline (create urgency)
- 3 bullet points showing additional value
- "Add to order" CTA
- Time-limited discount (show original vs. discounted price)

**Cross-sell Email (Send 3 days after purchase)**
- Subject line (3 options)
- Body (200 words max)
- Natural bridge from what they bought to what you're suggesting
- Social proof specific to the cross-sell

**Cart Upsell (Before Checkout)**
- Headline (8 words max)
- Value comparison (what they get for [SMALL ADDITIONAL PRICE])
- Checkbox CTA text

Each piece should feel helpful, not pushy. Frame it as "customers who bought X also loved Y."
```

### How to Use
Post-purchase upsells convert at 10-30% if the offer is relevant and time-limited. Always test.

---

## Prompt 11: Cold Email (B2B Outreach)

### Prompt

```
Write a 3-email cold outreach sequence for [YOUR BUSINESS].

Context:
- You sell: [PRODUCT/SERVICE]
- Target: [JOB TITLE] at [COMPANY TYPE]
- Their likely pain point: [PAIN POINT]
- Your key differentiator: [WHAT MAKES YOU DIFFERENT]
- Desired action: [BOOK A CALL / START A TRIAL / REPLY]

**Email 1: The Opener (Day 0)**
- Subject line: under 5 words, no caps, looks personal
- Opening line that shows you did research (use [SPECIFIC DETAIL ABOUT THEIR COMPANY])
- One sentence about the problem
- One sentence about your solution
- Soft CTA: question, not demand
- Under 80 words total

**Email 2: The Value Add (Day 3)**
- Subject line: Re: [original subject] OR new angle
- Share a relevant insight, stat, or case study
- Connect it to their situation
- Slightly stronger CTA
- Under 60 words

**Email 3: The Breakup (Day 7)**
- Subject line: casual, shows you're moving on
- Acknowledge they're busy
- One final value statement
- Permission-based close: "Should I close your file?"
- Under 50 words

All emails must feel 1-to-1, never templated. No corporate jargon.
```

### How to Use
Personalize the [SPECIFIC DETAIL] for each prospect. Generic cold emails get <1% reply rates. Personalized ones get 5-15%.

---

## Prompt 12: Guarantee & Risk Reversal Copy

### Prompt

```
Write guarantee and risk reversal copy for [PRODUCT/SERVICE] at [PRICE].

Context:
- Product: [PRODUCT/SERVICE]
- Price: [PRICE]
- Guarantee period: [30/60/90 DAYS]
- Target audience: [TARGET AUDIENCE]
- Biggest purchase objection: [WHAT HOLDS THEM BACK]

Write 5 guarantee variations:
1. **Simple money-back** — Clean, no-questions-asked
2. **Better-than-money-back** — Refund PLUS keep the product
3. **Results-based** — Guarantee specific outcome or refund
4. **Double guarantee** — Combine time-based + results-based
5. **Try-before-you-buy** — Free trial or sample approach

For each:
- Headline (bold, confident)
- Body (2-3 sentences)
- Fine print (honest, clear terms)

Also write a "Why we can offer this guarantee" section (builds credibility).
```

### How to Use
Stronger guarantees always increase conversions. The risk of refunds is almost always worth the increased sales.

---

## Pro Tips: Copywriting

1. **The 4 U's** — Every headline should be Useful, Urgent, Unique, and Ultra-specific
2. **Features tell, benefits sell** — Always connect what it IS to what it DOES for them
3. **One CTA per page** — Multiple CTAs reduce conversions. Pick one action.
4. **Social proof > claims** — "500 customers" beats "amazing product" every time
5. **Write for scanners** — Bold key phrases, use bullets, short paragraphs
6. **The "So What?" test** — After every sentence, ask "so what?" If you can't answer, rewrite it
7. **Specificity wins** — "$12,847 in 6 weeks" beats "thousands of dollars fast"
