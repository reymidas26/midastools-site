# Midas Tools — AI Prompt Mega Pack
# 02: Social Media & Growth Prompts

Grow your audience and engagement with AI-powered social media content. From viral tweets to LinkedIn authority posts, these prompts turn you into a content machine.

---

## Variables Reference

```
[YOUR BRAND] — Your business or personal brand name
[YOUR NICHE] — Your area of expertise
[TARGET AUDIENCE] — Who you want to attract
[PLATFORM] — Twitter/X, LinkedIn, Instagram, TikTok, etc.
[TOPIC] — The subject of your post
[KEY MESSAGE] — The main point you want to make
[YOUR EXPERIENCE] — Relevant personal experience or credential
[CONTENT PILLAR] — One of your 3-5 recurring themes
[TONE] — professional, witty, provocative, inspirational, educational
```

---

## Prompt 1: Twitter/X Thread Generator

### Prompt

```
Write a viral Twitter/X thread about [TOPIC] for my audience of [TARGET AUDIENCE].

Context:
- My niche: [YOUR NICHE]
- Key message: [KEY MESSAGE]
- My experience: [YOUR EXPERIENCE]

Thread structure (10 tweets):
- Tweet 1: Hook — bold claim, surprising stat, or contrarian take. Must stop the scroll.
- Tweets 2-3: Set up the problem or context
- Tweets 4-7: Deliver the value (steps, insights, examples)
- Tweet 8-9: Real-world example or case study
- Tweet 10: Summary + CTA (follow for more, retweet if useful, link to resource)

Rules:
- Each tweet under 280 characters
- No hashtags (they reduce reach on X)
- Use line breaks for readability
- Start tweet 1 with a hook, not "Thread:" or "🧵"
- Include at least one tweet with a specific number or stat
- Write in first person, conversational tone

Also suggest: Best time to post, and a quote-tweet follow-up for engagement.
```

### How to Use
Post threads on Tuesday-Thursday between 8-10am or 12-2pm (your audience's timezone). Pin the thread after 1 hour if it gets traction.

---

## Prompt 2: LinkedIn Authority Post

### Prompt

```
Write a LinkedIn post that establishes me as an authority in [YOUR NICHE].

Context:
- My role: [YOUR TITLE/ROLE]
- My niche: [YOUR NICHE]
- Topic: [TOPIC]
- Key insight: [KEY MESSAGE]
- Personal experience: [YOUR EXPERIENCE]

Format: Use the "Hook → Story → Lesson → CTA" framework.

Requirements:
- Hook (first 2 lines): Must make people click "see more" — use a bold statement, question, or surprising number
- Story (3-5 short paragraphs): Share a personal experience related to [TOPIC]
- Lesson (2-3 paragraphs): Extract the actionable insight
- CTA: Ask a question to drive comments (LinkedIn rewards comments > likes)

Style rules:
- Short paragraphs (1-2 sentences each)
- One sentence per line for emphasis
- Use "↳" or "→" for bullet points (not standard bullets)
- No emojis in the first line (looks spammy)
- No hashtags in the body (put 3-5 at the very end)
- 1,300 characters max for optimal reach
- First person, vulnerability + authority balance

Write 3 versions: Storytelling, Data-driven, Contrarian take.
```

### How to Use
Post Monday-Friday 7-9am. Comment on 10 posts before and after publishing (algorithm boost). Reply to every comment within 1 hour.

---

## Prompt 3: Instagram Carousel Script

### Prompt

```
Write an Instagram carousel (10 slides) about [TOPIC] for [TARGET AUDIENCE].

Context:
- My niche: [YOUR NICHE]
- Key message: [KEY MESSAGE]
- Desired action: [FOLLOW / SAVE / SHARE / LINK IN BIO]

Slide structure:
- **Slide 1 (Cover):** Bold headline that creates curiosity. 5-8 words max. Design note: large text, contrasting background.
- **Slides 2-3:** Set up the problem — why this matters
- **Slides 4-8:** Main content — tips, steps, or framework (one point per slide)
- **Slide 9:** Summary or key takeaway
- **Slide 10:** CTA — tell them exactly what to do next

For each slide provide:
- **Text:** What appears on the slide (keep it SHORT — 15-25 words max)
- **Design note:** Color, layout, or visual suggestion
- **Caption:** Full Instagram caption (2,200 chars max) with:
  - Hook (first line visible in feed)
  - Value expansion
  - CTA
  - 5 relevant hashtags (mix of large and niche)

Also suggest: Reel idea that complements this carousel (for cross-format reach).
```

### How to Use
Carousels get 3x more engagement than single images. Post and immediately share to your story with a poll sticker.

---

## Prompt 4: TikTok/Reels Script

### Prompt

```
Write a TikTok/Reels script about [TOPIC] for [TARGET AUDIENCE].

Context:
- My niche: [YOUR NICHE]
- Video length: [15/30/60 SECONDS]
- Style: [TALKING HEAD / VOICEOVER / TEXT-ON-SCREEN / SKIT]

Script structure:

**Hook (0-3 seconds):**
Write 3 hook options. Each must stop the scroll immediately.
- Pattern interrupt, bold claim, or "Wait..." opener
- The hook determines 90% of performance

**Body (3-[LENGTH-5] seconds):**
- Main content delivered in short, punchy sentences
- Include visual/action cues in [brackets]
- Keep each point to 1-2 sentences max

**Payoff (last 3-5 seconds):**
- Deliver the punchline, result, or surprise
- CTA: Follow for part 2, comment your answer, share this

Also include:
- Caption (150 chars with hook + CTA)
- 5 hashtag suggestions
- Trending audio suggestion (describe the vibe)
- Best posting time for [TARGET AUDIENCE]

Write 3 complete script variations with different angles.
```

### How to Use
Film all 3 variations in one session. Post the best-performing hook style more often. Respond to every comment in the first hour.

---

## Prompt 5: Content Calendar (30 Days)

### Prompt

```
Create a 30-day social media content calendar for [YOUR BRAND] on [PLATFORM].

Context:
- Niche: [YOUR NICHE]
- Target audience: [TARGET AUDIENCE]
- Content pillars (pick 3-5): [LIST YOUR RECURRING THEMES]
- Posting frequency: [HOW OFTEN PER WEEK]
- Products/services to promote: [PRODUCT/SERVICE]

For each day, provide:
- **Date** (Day 1-30)
- **Content pillar** (which theme)
- **Post type** (educational, story, promotional, engagement, trending)
- **Topic/headline** (specific, not generic)
- **Hook** (first line)
- **CTA** (what action to take)
- **Format** (text, image, carousel, video, poll)

Rules:
- Max 20% promotional content (80/20 rule)
- Alternate between content pillars
- Include 2-3 trending/timely topics
- Include 4 engagement posts (questions, polls, "this or that")
- Build toward a promotional push in week 4
- Every Friday: community/engagement post
- Every Monday: educational/value post

Present as a table for easy reference.
```

### How to Use
Batch-create content weekly. Adjust based on what performs. Double down on formats and topics that get engagement.

---

## Prompt 6: Viral Hook Database

### Prompt

```
Generate 30 viral hooks for [PLATFORM] about [YOUR NICHE].

Target audience: [TARGET AUDIENCE]
Goal: Stop the scroll and make people engage.

Create 5 hooks for each category:

**1. Contrarian (challenge common belief)**
"Most people think [X]. They're wrong. Here's why..."

**2. Number/List (specific and scannable)**
"[NUMBER] [THINGS] I wish I knew about [TOPIC] before [MILESTONE]"

**3. Story (personal narrative)**
"[TIME PERIOD] ago, I [SITUATION]. Here's what happened..."

**4. Question (create curiosity)**
"Why do [PERCENTAGE]% of [AUDIENCE] fail at [GOAL]?"

**5. Result (social proof)**
"I [DID X] and [GOT RESULT] in [TIMEFRAME]. Here's the playbook:"

**6. Controversial (polarizing but professional)**
"Unpopular opinion: [BOLD STATEMENT ABOUT YOUR NICHE]"

For each hook:
- Write the complete opening line (ready to use)
- Rate engagement potential 1-5
- Note which platform it works best on
- Suggest the format (thread, carousel, video, text post)

Sort by engagement potential, highest first.
```

### How to Use
Save these as a swipe file. Use one hook per post. Test which categories perform best with YOUR audience.

---

## Prompt 7: Comment & Engagement Replies

### Prompt

```
I need smart, engaging replies for social media comments and DMs.

My brand: [YOUR BRAND]
My niche: [YOUR NICHE]
My tone: [TONE]

Write replies for these common scenarios:

**Positive comments:**
1. "Great post!" (generic praise)
2. "This changed my perspective on [topic]"
3. "I needed this today"
4. Someone sharing their own experience

**Questions:**
5. "How do I get started with [topic]?"
6. "Does this work for [specific situation]?"
7. "What tools do you recommend?"
8. "Can you make a post about [request]?"

**Negative/skeptical:**
9. "This doesn't work" (dismissive)
10. "Easy to say when you're already successful"
11. "You're just trying to sell something"
12. "I disagree because [reason]"

For each, write 2-3 reply options that:
- Feel genuine (not copy-paste)
- Continue the conversation (ask a follow-up question)
- Build relationship (not just "thanks!")
- Show personality matching [TONE]
- Are under 50 words each
```

### How to Use
Replying to every comment within 1 hour boosts your reach dramatically. Use these as templates but personalize each one.

---

## Prompt 8: Social Media Bio Optimizer

### Prompt

```
Write optimized social media bios for all my platforms.

About me:
- Name: [YOUR NAME]
- Niche: [YOUR NICHE]
- Key credential: [YOUR EXPERIENCE/CREDENTIAL]
- What I help people do: [TRANSFORMATION YOU PROVIDE]
- CTA: [WHAT YOU WANT PEOPLE TO DO — follow, visit link, DM]
- Link: [YOUR URL]

Write bios for:

**Twitter/X (160 chars max):**
- Version 1: Authority-focused
- Version 2: Personality-focused
- Version 3: Result-focused

**LinkedIn (2,000 chars max):**
- Professional headline (120 chars)
- Summary paragraph (300 words)
- Include keywords: [3-5 KEYWORDS FOR SEARCH]

**Instagram (150 chars max):**
- Version 1: Clear and direct
- Version 2: Creative with emoji structure
- Version 3: Social proof focused

**TikTok (80 chars max):**
- Version 1: Niche authority
- Version 2: Personality + niche

For each platform, follow the unique culture and norms. What works on LinkedIn doesn't work on TikTok.
```

### How to Use
Update your bios quarterly. Your bio is the #1 factor in follow-back rate. Test different versions and track follower growth.

---

## Prompt 9: Hashtag Strategy

### Prompt

```
Create a comprehensive hashtag strategy for [YOUR BRAND] on [PLATFORM].

Niche: [YOUR NICHE]
Target audience: [TARGET AUDIENCE]
Content pillars: [LIST 3-5 THEMES]

Provide:

**Tier 1: Niche hashtags (under 100K posts)**
- 10 hashtags specific to [YOUR NICHE]
- These are where you can actually rank

**Tier 2: Mid-range (100K-1M posts)**
- 10 hashtags with moderate competition
- Your content can appear in "Top" with decent engagement

**Tier 3: Broad (1M+ posts)**
- 5 hashtags for maximum reach
- Use sparingly, only on your best content

**Branded hashtag:**
- Suggest a unique hashtag for [YOUR BRAND]
- Explain how to get your audience using it

**Hashtag sets (save these for quick posting):**
- Set A: Educational content
- Set B: Personal/story content
- Set C: Promotional content
- Set D: Engagement/community content

Each set should have 15-20 hashtags mixing all tiers.
Rules: No banned hashtags. Research if each hashtag is still active.
```

### How to Use
Rotate between sets. Never use the same hashtags twice in a row (platform algorithms penalize this). Update monthly.

---

## Prompt 10: Social Proof Amplifier

### Prompt

```
Help me turn customer results into social media content for [YOUR BRAND].

Customer result: [DESCRIBE A SPECIFIC CUSTOMER WIN — what they achieved, timeline, starting point]
Product/service they used: [PRODUCT/SERVICE]
Platform: [WHERE TO POST]

Create:

1. **Screenshot-style post** — Write the "customer quote" as it would appear in a DM or testimonial screenshot. Make it feel real and unpolished.

2. **Case study thread/carousel** —
   - Hook: The result (specific number)
   - Context: Where they started
   - Process: What they did (3-5 steps)
   - Result: Specific outcome
   - Lesson: What others can learn
   - CTA: How to get similar results

3. **Before/After comparison** — Text for a side-by-side visual showing the transformation

4. **Engagement post** — Turn the result into a question: "Is [result] realistic in [timeframe]? Here's what actually happened..."

5. **Story slides** — 3-5 Instagram/Facebook story slides telling the customer's journey

For each format:
- Write the complete copy (ready to post)
- Include platform-specific formatting
- Add relevant hashtags/keywords
```

### How to Use
Turn every customer win into 5+ pieces of content. Social proof is the most persuasive content type on every platform.

---

## Prompt 11: Engagement Bait (Ethical)

### Prompt

```
Write 10 high-engagement social media posts for [YOUR NICHE] on [PLATFORM].

These posts are designed to drive comments, saves, and shares — NOT to be clickbait.

Target audience: [TARGET AUDIENCE]
Tone: [TONE]

Post types to create:

1. **"This or That"** — Two options related to [YOUR NICHE], ask which they prefer
2. **Unpopular opinion** — Share a genuine contrarian view with reasoning
3. **Fill in the blank** — "___ is the most underrated tool for [NICHE]"
4. **Hot take** — Brief, bold statement that invites debate
5. **Poll/Question** — Direct question about their experience
6. **"Rate my..."** — Share something and ask for honest feedback
7. **Prediction** — Bold prediction about the future of [YOUR NICHE]
8. **Confession** — Admit a mistake or misconception you had
9. **Challenge** — Challenge your audience to do something and share results
10. **Ranking** — Rank popular things in your niche, ask if they agree

For each post:
- Write the complete copy (ready to post)
- Explain why this format drives engagement
- Suggest the best time to post
- Write 3 seed comments you can use to kickstart the conversation
```

### How to Use
Post 2-3 engagement posts per week between your educational content. Engagement signals boost your overall account reach.

---

## Pro Tips: Social Media

1. **The 1-hour rule** — Be most active in the first hour after posting (reply to every comment)
2. **Engage before you post** — Spend 15 mins commenting on others' posts, then publish yours
3. **Repurpose ruthlessly** — One idea = tweet + LinkedIn post + carousel + video + newsletter
4. **Pin your best** — Pin your highest-performing post to your profile
5. **Content pillars, not random posts** — Stick to 3-5 themes so people know what to follow you for
6. **The 80/20 rule** — 80% value, 20% promotion. Break this and you'll lose followers.
7. **Save > Like** — If people save your post, the algorithm promotes it. Create saveable content (tips, frameworks, checklists)
